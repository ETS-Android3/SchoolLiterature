package fitisov123.schoolliterature;

import android.app.Fragment;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BookListFragment extends Fragment {

    private static String grade, names, authors;
    private EditText search_et;
    private ListView bookList;
    private Context context;
    private ArrayList<String> namesArray, authorsArray;
    private ArrayList<HashMap<String, String>> arrayList;
    private SimpleAdapter adapter;
    private InterstitialAd interstitialAd;

    public static void afterAsyncRequest(){
        grade = DataStorage.getGrade();
        names = DataStorage.getTextNames();
        authors = DataStorage.getTextAuthors();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        context = getActivity().getApplicationContext();
        final View layout = inflater.inflate(R.layout.fragment_book_list, container, false);
        bookList = (ListView) layout.findViewById(R.id.regular_books_list);
        search_et = (EditText) layout.findViewById(R.id.search_et);

        namesArray = makeArray(names);
        authorsArray = makeArray(authors);

        MainActivity.updateAppBar("Школьная Литература", R.color.mainSHLthemeDARK);

        arrayList = new ArrayList<>();

        initArrayList();
        initList();

        search_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                initArrayList();
                if(s.toString().equals("")){
                    initList();
                }
                else{
                    searchItem(s.toString());
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        MobileAds.initialize(context, getString(R.string.admob_app_id));
        interstitialAd = new InterstitialAd(context);
        interstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712"/*getString(R.string.admob_unit_id)*/);
        AdRequest adRequest = new AdRequest.Builder().build();
        interstitialAd.loadAd(adRequest);

        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                interstitialAd.loadAd(new AdRequest.Builder().build());
            }
        });

        bookList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View chosenItem, int position, long id) {
                Logger logger = Logger.getLogger(BookListFragment.class.getName());
                logger.log(Level.INFO, interstitialAd.isLoaded() ? "LOADED" : "NOT LOADED");
                if(interstitialAd.isLoaded())
                    interstitialAd.show();
                boolean connected = false;
                ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                        connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
                    connected = true;
                }
                if(!connected) {
                    Toast.makeText(context, "Необходимо подключение к интернету", Toast.LENGTH_LONG).show();
                }
                else {
                    String textName = ((TextView) chosenItem.findViewById(R.id.textName)).getText().toString();
                    String textAuthor = ((TextView) chosenItem.findViewById(R.id.textAuthor)).getText().toString();
                    MainActivity.inflateFragment(new BookTextFragment());
                    MainActivity.updateAppBar(textName, R.color.mainSHLthemeDARK);

                    new BookTextRequest(context).execute(grade, textName, textAuthor);
                }
            }
        });

        return layout;
    }

    public void initArrayList(){
        arrayList.clear();
        HashMap<String, String> map;

        for(int i = 0; i < namesArray.size(); i++) {
            map = new HashMap<>();
            map.put("Name", namesArray.get(i));
            map.put("Author", authorsArray.get(i));
            arrayList.add(map);
        }
    }

    public void initList(){
        adapter = new SimpleAdapter(context, arrayList, R.layout.books_item_list,
                new String[]{"Name", "Author"},
                new int[]{R.id.textName, R.id.textAuthor});

        bookList.setAdapter(adapter);
    }

    public void searchItem(String input){
        ArrayList<HashMap<String, String>> del_aL = new ArrayList<>();
        input = input.toLowerCase();
        for(HashMap<String, String> item : arrayList){
            if(!item.get("Name").toLowerCase().contains(input) && !item.get("Author").toLowerCase().contains(input)){
                del_aL.add(item);
            }
        }
        arrayList.removeAll(del_aL);
    }

    public ArrayList<String> makeArray(String dataStr)
    {
        int prevI = 0;
        ArrayList<String> resArr = new ArrayList<>();
        for(int i = 0; i < dataStr.length(); i++)
        {
            if(dataStr.charAt(i) == ';')
            {
                String subs = dataStr.substring(prevI, i);
                resArr.add(subs);
                prevI = i+1;
            }
        }
        return resArr;
    }

}
