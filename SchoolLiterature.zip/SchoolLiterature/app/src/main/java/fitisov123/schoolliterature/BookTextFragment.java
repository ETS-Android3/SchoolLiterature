package fitisov123.schoolliterature;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class BookTextFragment extends android.app.Fragment{

    private static String textName, textAuthor, textText;
    private static TextView text_tv;
    private static Context context;
    private static SharedPreferences sp;
    private static View layout;
    private static FrameLayout frameLayout;
    private static ArrayList<String> notesArray;
    private static Dialog innerDialog;
    private static ScrollView scrollView;
    private static HashMap<String, Integer> localNotesHM = new HashMap<>();
    private static FloatingActionButton fab;
    private static View chosenItem;
    private static TextView noNotesTv;
    private static ListView notes;
    private static View ld;
    private static boolean inHere = false;
    private static ProgressBar loadingpb;
    public static TextView loading_tv;

    public static void afterAsyncRequest(){
        textName = DataStorage.getCurTextName();
        textAuthor = DataStorage.getCurTextAuthor();
        textText = DataStorage.getCurText();
        loadingpb.setVisibility(View.GONE);
        loading_tv.setVisibility(View.GONE);

        text_tv.setText(textText);
        final int textLastPosition = CacheManager.getTextLastPosition(context, textName);
        scrollView = (ScrollView) layout.findViewById(R.id.scrollText);
        scrollView.post(new Runnable() {
            public void run() {
                scrollView.scrollTo(0, textLastPosition); //Восстановим позицию scrollView
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        context = getActivity().getApplicationContext();
        layout = inflater.inflate(R.layout.fragment_text, container, false);
        inHere = true;

        frameLayout = layout.findViewById(R.id.textLayout);

        text_tv = layout.findViewById(R.id.bookText);

        ld = layout.findViewById(R.id.loading);
        loadingpb = ld.findViewById(R.id.loadingBar);
        loading_tv = ld.findViewById(R.id.loadingWarning);

        Typeface typeface = Typeface.createFromAsset(context.getAssets(), "FontForShl.ttf");
        text_tv.setTypeface(typeface);

        fab = (FloatingActionButton) layout.findViewById(R.id.floting_button);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(getActivity());

                dialog.setContentView(R.layout.dialog_notes);

                notes = (ListView) dialog.findViewById(R.id.notes_list);
                noNotesTv = (TextView) dialog.findViewById(R.id.noNotes_tv);
                final Button add_note = (Button) dialog.findViewById(R.id.add_note);

                initialiseNotesList();

                notes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        chosenItem = view;
                        scrollView.post(new Runnable() {
                            public void run() {
                                scrollView.scrollTo(0, localNotesHM.get((chosenItem.getTag()))); //Восстановим позицию scrollView
                            }
                        });

                        dialog.dismiss();
                    }
                });

                add_note.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        createInnerDialog();
                    }
                });

                dialog.show();
            }
        });

        final int new_size = CacheManager.getSettingsTextSize(context);
        BookTextFragment.setText_tvSize(new_size);

        final boolean nightMode = CacheManager.getSettingsNightMode(context);
        BookTextFragment.switchToNightMode(nightMode);

        return layout;
    }

    public void createInnerDialog(){
        innerDialog = new Dialog(getActivity());
        innerDialog.setContentView(R.layout.dialog_adding_note);
        final EditText newNoteEt = (EditText) innerDialog.findViewById(R.id.adding_note_et);
        final Button submittingNote = (Button) innerDialog.findViewById(R.id.submitting_new_note);
        final ProgressBar loadingPB = (ProgressBar) innerDialog.findViewById(R.id.adding_note_loadingPB);

        submittingNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submittingNote.setClickable(false);
                submittingNote.setVisibility(View.GONE);
                loadingPB.setVisibility(View.VISIBLE);
                String newNoteName = newNoteEt.getText().toString();
                String newNotePosition = String.valueOf(((ScrollView)layout.findViewById(R.id.scrollText)).getScrollY());
                DataStorage.addToCurGradeNotesStr(newNoteName, newNotePosition);
                DataStorage.updateCurGradePartInFullNotesStr();
                new UserDataRequest(getActivity()).execute("updNotesAdd", DataStorage.getUserId(), DataStorage.getFullNotesStr());
            }
        });

        innerDialog.show();
    }

    public static void afterAddingNote(){
        innerDialog.dismiss();
    }

    public static void initialiseNotesList(){
        notesArray = DataStorage.getNotesHM().get(DataStorage.getCurTextName());

        if(notesArray == null || notesArray.isEmpty()){
            noNotesTv.setVisibility(View.VISIBLE);
            notes.setVisibility(View.GONE);
        }
        else {
            ArrayList<String> noteTitles = new ArrayList<>();
            for(String note : notesArray){
                for(int i = 0; i < note.length(); i++){
                    if(note.charAt(i) == '~'){
                        String curTitle = note.substring(0, i);
                        localNotesHM.put(curTitle, Integer.valueOf(note.substring(i+1)));
                        noteTitles.add(curTitle);
                    }
                }
            }
            NotesListAdapter notesListAdapter = new NotesListAdapter(context, noteTitles);
            notes.setAdapter(notesListAdapter);
        }
    }

    public static void initialiseNotesList(ArrayList<String> noteTitles){
        if(noteTitles.isEmpty()){
            noNotesTv.setVisibility(View.VISIBLE);
            notes.setVisibility(View.GONE);
        }
        else {
            NotesListAdapter notesListAdapter = new NotesListAdapter(context, noteTitles);
            notes.setAdapter(notesListAdapter);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        int textLastPosition = ((ScrollView)layout.findViewById(R.id.scrollText)).getScrollY();
        CacheManager.setTextLastPosition(context, textName, textLastPosition);
        inHere = false;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        int textLastPosition = ((ScrollView)layout.findViewById(R.id.scrollText)).getScrollY();
        CacheManager.setTextLastPosition(context, textName, textLastPosition);
        inHere = false;
        MainActivity.updateAppBar("Школьная Литература", R.color.mainSHLthemeDARK);
    }

    public static void setText_tvSize(int new_size) {
        if(text_tv != null)
            text_tv.setTextSize(new_size);
    }

    public static void switchToNightMode(boolean toNight){
        if(inHere && text_tv != null && frameLayout != null && fab != null && loadingpb != null && loading_tv != null)
        {
            if(toNight){
                text_tv.setTextColor(ContextCompat.getColor(context, R.color.DayModeBackground));
                frameLayout.setBackgroundColor(ContextCompat.getColor(context, R.color.NightModeBackground));
                MainActivity.toolbar.setBackgroundColor(ContextCompat.getColor(context, R.color.NightModeAppBar));
                fab.setBackgroundTintList(ColorStateList.valueOf(context.getResources().getColor(R.color.DayModeBackground)));
                fab.setImageResource(R.drawable.ic_fab_dark);
                Drawable progressDrawable = loadingpb.getIndeterminateDrawable().mutate();
                progressDrawable.setColorFilter(context.getResources().getColor(R.color.DayModeBackground), android.graphics.PorterDuff.Mode.SRC_IN);
                loadingpb.setProgressDrawable(progressDrawable);
                loading_tv.setTextColor(ContextCompat.getColor(context, R.color.DayModeBackground));
            }
            else{
                text_tv.setTextColor(ContextCompat.getColor(context, R.color.NightModeBackground));
                frameLayout.setBackgroundColor(ContextCompat.getColor(context, R.color.DayModeBackground));
                MainActivity.toolbar.setBackgroundColor(ContextCompat.getColor(context, R.color.mainSHLthemeDARK));
                fab.setBackgroundTintList(ColorStateList.valueOf(context.getResources().getColor(R.color.NightModeBackground)));
                fab.setImageResource(R.drawable.ic_fab_light);
                Drawable progressDrawable = loadingpb.getIndeterminateDrawable().mutate();
                progressDrawable.setColorFilter(context.getResources().getColor(R.color.NightModeBackground), android.graphics.PorterDuff.Mode.SRC_IN);
                loadingpb.setProgressDrawable(progressDrawable);
                loading_tv.setTextColor(ContextCompat.getColor(context, R.color.NightModeBackground));
            }
        }
    }
}
