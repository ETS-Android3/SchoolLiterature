package fitisov123.schoolliterature;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class BookTextRequest extends AsyncTask<String, Integer, String> {

    private final String URL_SERVER = "https://salty-peak-15288.herokuapp.com/classes/";
    private Context context;
    public BookTextRequest(Context context){
        this.context = context;
    }

    @Override
    protected String doInBackground(String... arg) {
        String query = URL_SERVER + arg[0] + "/" + arg[1] + ".txt";
        DataStorage.setCurTextName(arg[1]);
        DataStorage.setCurTextAuthor(arg[2]);
        return performPostCall(query);
    }

    @Override
    protected void onPostExecute(String text) {
        super.onPostExecute(text);
        if(text.equals("error")){
            Toast.makeText(context, "Ошибка при получении текста с сервера!", Toast.LENGTH_LONG);
            return;
        }
        DataStorage.setCurText(text);
        BookTextFragment.afterAsyncRequest();
    }

    public String performPostCall(String query) {
        URL url;
        String response = "";

        response = CacheManager.getTextInCache(context, DataStorage.getCurTextName(), DataStorage.getCurTextAuthor());
        if(response != null){
            return response;
        }
        else{
            response = "";
        }
        try{
            query = query.replace(" ", "%20");
            url = new URL(query);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setReadTimeout(60000);
            connection.setConnectTimeout(60000);
            connection.setDoInput(true);
            connection.setDoOutput(true);

            int responseCode = connection.getResponseCode();

            if(responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = reader.readLine();
                while(line != null) {
                    response += line;
                    if(line.length() != 0)
                        response += System.getProperty ("line.separator");
                    line = reader.readLine();
                }
            }
            else{
                response = connection.getResponseMessage();
            }

        } catch (Exception e) {
            e.printStackTrace();
            response = "error";
        }
        if(response != "error") {
            CacheManager.setTextInCache(context, DataStorage.getCurTextName(), DataStorage.getCurTextAuthor(), response);
        }
        return response;
    }
}
