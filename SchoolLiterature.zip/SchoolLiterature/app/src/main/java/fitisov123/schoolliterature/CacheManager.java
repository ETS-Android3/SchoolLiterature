package fitisov123.schoolliterature;

import android.content.Context;
import android.content.SharedPreferences;

public class CacheManager {
    private static final String positionCache = "SchoolLiteraturePositionCache";
    private static final String settingsCache = "SchoolLiteratureSettingsCache";
    private static final String textCache = "SchoolLiteratureTextCache";
    private static final String userDataCache = "SchoolLiteratureUserDataCache";

    public static int getTextLastPosition(Context context, String textName){
        SharedPreferences sp = context.getSharedPreferences(positionCache, Context.MODE_PRIVATE);
        int textLastPosition = sp.getInt(textName, 0);
        return textLastPosition;
    }

    public static void setTextLastPosition(Context context, String textName, int textLastPosition){
        SharedPreferences sp = context.getSharedPreferences(positionCache, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(textName, textLastPosition);
        ed.commit();
    }

    public static int getSettingsTextSize(Context context){
        SharedPreferences sp = context.getSharedPreferences(settingsCache, Context.MODE_PRIVATE);
        int textSize = sp.getInt("textSize", 20);
        return textSize;
    }

    public static void setSettingsTextSize(Context context, int textSize){
        SharedPreferences sp = context.getSharedPreferences(settingsCache, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("textSize", textSize);
        ed.commit();
    }

    public static boolean getSettingsNightMode(Context context){
        SharedPreferences sp = context.getSharedPreferences(settingsCache, Context.MODE_PRIVATE);
        boolean nightMode = sp.getBoolean("nightMode", false);
        return nightMode;
    }

    public static void setSettingsNightMode(Context context, boolean nightMode){
        SharedPreferences sp = context.getSharedPreferences(settingsCache, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean("nightMode", nightMode);
        ed.commit();
    }

    public static String getUserDataLogin(Context context){
        SharedPreferences sp = context.getSharedPreferences(userDataCache, Context.MODE_PRIVATE);
        if(!sp.contains("login"))
            return null;
        return sp.getString("login", "");
    }

    public static void setUserDataLogin(Context context, String login){
        SharedPreferences sp = context.getSharedPreferences(userDataCache, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.remove("login");
        ed.putString("login", login);
        ed.commit();
    }

    public static String getUserDataPassword(Context context){
        SharedPreferences sp = context.getSharedPreferences(userDataCache, Context.MODE_PRIVATE);
        if(!sp.contains("password"))
            return null;
        return sp.getString("password", "");
    }

    public static void setUserDataPassword(Context context, String password){
        SharedPreferences sp = context.getSharedPreferences(userDataCache, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.remove("password");
        ed.putString("password", password);
        ed.commit();
    }

    public static String getTextInCache(Context context, String textName, String textAuthor){
        SharedPreferences sp = context.getSharedPreferences(textCache, Context.MODE_PRIVATE);
        if(!sp.contains(textName + textAuthor))
            return null;
        return sp.getString(textName + textAuthor, "error");
    }

    public static void setTextInCache(Context context, String textName, String textAuthor, String textText){
        SharedPreferences sp = context.getSharedPreferences(textCache, Context.MODE_PRIVATE);
        if(sp.contains(textName + textAuthor))
            return;
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(textName + textAuthor, textText);
        ed.commit();
    }
}
