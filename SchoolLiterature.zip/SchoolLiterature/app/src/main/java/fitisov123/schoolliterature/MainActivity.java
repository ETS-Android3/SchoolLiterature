package fitisov123.schoolliterature;

import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private static FragmentManager fragmentManager;
    private static FragmentTransaction fragmentTransaction;

    private static String name, surname, grade, user_id;
    private static View header;
    private static Context context;
    public static Toolbar toolbar;
    private static NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        Drawable drawable = ContextCompat.getDrawable(getApplicationContext(),R.drawable.ic_text_settings);
        toolbar.setOverflowIcon(drawable);
        //toolbar.setNavigationIcon(ContextCompat.getDrawable(getApplicationContext(),R.drawable.ic_nav_menu));

        context = this;

        header = navigationView.getHeaderView(0);

        fragmentManager = getFragmentManager();

        MainActivity.afterAsyncRequest();

        MainActivity.toolbar.setClickable(true);

        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.startLayout, new BookListFragment());
        fragmentTransaction.commit();
        navigationView.getMenu().getItem(1).setChecked(true);
    }

    public static void updateAppBar(String textName, int color){
        MainActivity.toolbar.setTitle(textName);
        MainActivity.toolbar.setTitleTextColor(ContextCompat.getColor(context, R.color.colorWhite));
        ((AppCompatActivity)context).setSupportActionBar(MainActivity.toolbar);

        MainActivity.toolbar.setBackgroundColor(ContextCompat.getColor(context, color));

        DrawerLayout drawer = (DrawerLayout) ((AppCompatActivity)context).findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                ((AppCompatActivity)context), drawer, MainActivity.toolbar , R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        toggle.syncState();
    }

    public static void updateAppBar(int color){
        ((AppCompatActivity)context).setSupportActionBar(MainActivity.toolbar);
        MainActivity.toolbar.setBackgroundColor(ContextCompat.getColor(context, color));

        DrawerLayout drawer = (DrawerLayout) ((AppCompatActivity)context).findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                ((AppCompatActivity)context), drawer, MainActivity.toolbar , R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        toggle.syncState();
    }

    public static void afterAsyncRequest(){
        getProfileData();
        updateHeader();
    }

    public static void getProfileData(){
        grade = DataStorage.getGrade();
        name = DataStorage.getName();
        surname = DataStorage.getSurname();
        user_id = DataStorage.getUserId();
    }

    public static void updateHeader(){
        TextView grade_tv = (TextView) header.findViewById(R.id.gradeView);
        TextView name_tv = (TextView) header.findViewById(R.id.nameView);

        grade_tv.setText(grade + " класс");
        name_tv.setText(name + " " + surname);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.text_settings_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.text_settings) {
            Dialog dialog = new Dialog(MainActivity.this);

            dialog.setTitle(R.string.text_settings);
            dialog.setContentView(R.layout.dialog_text_settings);

            final TextView textSize = (TextView) dialog.findViewById(R.id.textSize);
            final Button plus = (Button) dialog.findViewById(R.id.plus);
            final Button minus = (Button) dialog.findViewById(R.id.minus);
            final CheckBox checkNightMode = (CheckBox) dialog.findViewById(R.id.nightMode);

            final int size = CacheManager.getSettingsTextSize(context);
            textSize.post(new Runnable() {
                    public void run() {
                        textSize.setText(String.valueOf(size));
                    }
                });

            final boolean nightMode = CacheManager.getSettingsNightMode(context);
            textSize.post(new Runnable() {
                public void run() {
                    checkNightMode.setChecked(nightMode);
                    BookTextFragment.switchToNightMode(nightMode);
                }
            });

            checkNightMode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    BookTextFragment.switchToNightMode(isChecked);
                    InfoFragment.switchToNightMode(isChecked);
                    CacheManager.setSettingsNightMode(context, isChecked);
                }
            });

            plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int size = Integer.parseInt(textSize.getText().toString());
                    if(size == 35)
                        return;
                    int newSize = size + 1;
                    textSize.setText(String.valueOf(newSize));
                    BookTextFragment.setText_tvSize(newSize);
                    InfoFragment.setText_tvSize(newSize);
                    CacheManager.setSettingsTextSize(context, newSize);
                }
            });

            minus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int size = Integer.parseInt(textSize.getText().toString());
                    if(size == 5)
                        return;
                    int newSize = size - 1;
                    textSize.setText(String.valueOf(newSize));
                    BookTextFragment.setText_tvSize(newSize);
                    InfoFragment.setText_tvSize(newSize);
                    CacheManager.setSettingsTextSize(context, newSize);
                }
            });

            dialog.show();
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        item.setChecked(true);
        switch (id)
        {
            case R.id.nav_profile:
                inflateFragment(new ProfileFragment());
                break;

            case R.id.nav_regular_books:
                inflateFragment(new BookListFragment());
                break;

            case R.id.nav_info:
                inflateFragment(new InfoFragment());
                break;

            case R.id.nav_exit:
                exitProfile();
                break;
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void exitProfile(){
        Intent intent = new Intent(this, LoginActivity.class);
        intent.putExtra("from", "MainActivity");
        startActivity(intent);
    }

    public static void inflateFragment(Fragment fragment){
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.startLayout, fragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
}
