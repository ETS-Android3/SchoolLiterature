package fitisov123.schoolliterature;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class NotesListAdapter extends BaseAdapter {

    private LayoutInflater inflater;
    private ArrayList<String> arrayList;
    private Context context;

    public NotesListAdapter(Context context, ArrayList<String> arrayList) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public String getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = View.inflate(context, R.layout.notes_item_list, null);
        TextView title_tv = (TextView) view.findViewById(R.id.noteTitle);
        Button deleteButton = (Button) view.findViewById(R.id.deleteButton);
        title_tv.setText(getItem(position));
        view.setTag(getItem(position));

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = getItem(position);
                arrayList.remove(position);
                DataStorage.eraseFromGradeNotesStr(position);
                DataStorage.updateCurGradePartInFullNotesStr();
                new UserDataRequest(context).execute("updNotesErase", DataStorage.getUserId(), DataStorage.getFullNotesStr());
                BookTextFragment.initialiseNotesList(arrayList);
            }
        });

        return view;
    }
}
