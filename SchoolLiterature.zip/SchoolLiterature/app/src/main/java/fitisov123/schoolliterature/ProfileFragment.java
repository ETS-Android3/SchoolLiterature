package fitisov123.schoolliterature;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;

public class ProfileFragment extends Fragment {

    String name, surname, grade, userId;
    String[] classes = {"5", "6", "7", "8", "9", "10", "11"};
    Context context;
    Button submit_b;
    EditText name_et;
    EditText surname_et;
    Spinner grade_sp;
    ProgressBar pbsaving;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final View layout = inflater.inflate(R.layout.fragment_profile, container, false);
        context = getActivity().getApplicationContext();

        MainActivity.updateAppBar("Школьная Литература", R.color.mainSHLthemeDARK);

        submit_b = (Button) layout.findViewById(R.id.editProfileSubmit);
        name_et = (EditText) layout.findViewById(R.id.editName);
        surname_et = (EditText) layout.findViewById(R.id.editSurname);
        grade_sp = (Spinner) layout.findViewById(R.id.editGradeSpinner);
        pbsaving = (ProgressBar) layout.findViewById(R.id.progressBarSaving);

        name = DataStorage.getName();
        surname = DataStorage.getSurname();
        grade = DataStorage.getGrade();
        userId = DataStorage.getUserId();

        name_et.setText(name);
        surname_et.setText(surname);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(context, R.layout.item_spinner, classes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        grade_sp.setAdapter(adapter);
        grade_sp.setSelection(Integer.parseInt(grade) - 5);

        name_et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus)
                    name_et.setCursorVisible(true);
            }
        });

        surname_et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus)
                    surname_et.setCursorVisible(true);
            }
        });

        submit_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submit_b.setClickable(false);
                submit_b.setVisibility(View.GONE);
                pbsaving.setVisibility(View.VISIBLE);
                name = name_et.getText().toString();
                surname = surname_et.getText().toString();
                grade = grade_sp.getSelectedItem().toString();
                new UserDataRequest(context).execute("update_user", userId, name, surname, grade);
                new UserDataRequest(context).execute("login_with_id", String.valueOf(userId));
            }
        });

        return layout;
    }
}
