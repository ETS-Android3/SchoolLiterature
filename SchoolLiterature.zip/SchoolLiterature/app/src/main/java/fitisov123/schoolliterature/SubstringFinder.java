package fitisov123.schoolliterature;

public class SubstringFinder {

    public static int kmp(String text, String sample){
        String union = sample + "^" + text;
        int n = union.length();
        int[] pi = new int[n];
        pi[0] = 0;
        for(int i = 1; i < n; i++){
            int j = pi[i - 1];
            while(j > 0 && union.charAt(i) != union.charAt(j))
                j = pi[j - 1];
            if(union.charAt(i) == union.charAt(j))
                j++;
            pi[i] = j;
            if(pi[i] == sample.length())
                return i - 2 * sample.length();
        }
        return -1;
    }
}
